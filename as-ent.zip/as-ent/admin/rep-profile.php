<!DOCTYPE html>
<html lang="en">
    <head>
         <?php include 'style.php';?>
    </head>

    <body>
        <!-- ============================================================== -->
        <!-- main wrapper -->
        <!-- ============================================================== -->
        <div class="dashboard-main-wrapper">
            <!-- ============================================================== -->
            <!-- navbar -->
            <!-- ============================================================== -->
            <div class="dashboard-header">
                <?php include 'nav.php';?>
            </div>
            <!-- ============================================================== -->
            <!-- end navbar -->
            <!-- ============================================================== -->
            <!-- ============================================================== -->
            <!-- left sidebar -->
            <!-- ============================================================== -->
            <div class="nav-left-sidebar sidebar-dark">
                <div class="menu-list">
                     <?php include 'menu.php';?>
                </div>
            </div>
            <!-- ============================================================== -->
            <!-- end left sidebar -->
            <!-- ============================================================== -->
            <!-- ============================================================== -->
            <!-- wrapper  -->
            <!-- ============================================================== -->
            <div class="dashboard-wrapper">
                <div class="container dashboard-content">
                    <!-- ============================================================== -->
                    <!-- pagehader  -->
                    <!-- ============================================================== -->
                    <div class="row">
                        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                            <div class="page-header">
                                <h3 class="mb-2">Profile</h3>

                                <div class="page-breadcrumb">
                                    <nav aria-label="breadcrumb">
                                        <ol class="breadcrumb">
                                            <li class="breadcrumb-item"><a href="#" class="breadcrumb-link">ASE Admin</a></li>
                                            <li class="breadcrumb-item active" aria-current="page">Reports/Profile</li>
                                        </ol>
                                    </nav>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <!-- ============================================================== -->
                        <!-- ap and ar balance  -->
                        <!-- ============================================================== -->
                        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                            <div class="card">
                                <h5 class="card-header">Profile</h5>
                                <div class="card-body reports">
                                    <form action="#" role="form" class="" method="get" name="searchform" id="searchform" target="_blank" accept-charset="utf-8" autocomplete="off" novalidate="novalidate">
                                        <div class="row">
                                            <div class="col-sm-3 padding_both">
                                                <div class="form-group">
                                                    <input type="text" class="form-control" autocomplete="off" id="countfrom" name="countfrom" placeholder="Enter Count Start From" />
                                                </div>
                                            </div>
                                            <div class="col-sm-3 padding_both_small">
                                                <div class="form-group ok">
                                                    <input class="form-control" type="text" name="countto" id="countto" placeholder="Enter Count" />
                                                </div>
                                            </div>
                                            <div class="col-sm-3 padding_both_small">
                                                <div class="form-group">
                                                    <button type="submit" class="btn btn-primary" name="profile_view" value="View">View</button>
                                                </div>
                                            </div>
                                        </div>
                                    </form>

                                   
                                    
                                </div>

            <div class="button_back">
    <a href="#"><button class="btn m-b-xs btn-sm btn-primary btn-addon"><i class="fa fa-file-excel-o"></i>Create excel</button></a>     
      
    <a href="#"><button class="btn m-b-xs btn-sm btn-primary btn-addon hidden-xs hidden-sm hidden-md"><i class="fa fa-print"></i>Print</button>
    </a></div>



                                <table class="table status">
                                        <thead>
                                            <th>S.No</th>
                                            <th>Member Name</th>
                                            <th>Sponsor</th>
                                            <th>Email</th>
                                            <th>Mobile No</th>
                                            <th>Enrollment Date</th>
                                        </thead>
                                        <tbody>
                                            <tr>
            <td>1</td>
            <td>Faasith</td>
            <td>ASE1001</td>
            <td>faasith@gmail.com</td>
            <td>9876543210</td>
           
            <td>11 Feb 2021 - 06:46:53 AM</td>
        </tr>
         <tr>
            <td>2</td>
            <td>Faasith</td>
            <td>ASE1002</td>
            <td>faasith@gmail.com</td>
            <td>9876543210</td>
           
            <td>11 Feb 2021 - 06:46:53 AM</td>
        </tr>
         <tr>
            <td>3</td>
            <td>Faasith</td>
            <td>ASE1003</td>
            <td>faasith@gmail.com</td>
            <td>9876543210</td>
           
            <td>11 Feb 2021 - 06:46:53 AM</td>
        </tr>
         <tr>
            <td>4</td>
            <td>Faasith</td>
            <td>ASE1004</td>
            <td>faasith@gmail.com</td>
            <td>9876543210</td>
           
            <td>11 Feb 2021 - 06:46:53 AM</td>
        </tr>
                                        </tbody>
                                    </table>
                            </div>
                        </div>
                        <!-- ============================================================== -->
                        <!-- end ap and ar balance  -->
                        <!-- ============================================================== -->
                        <!-- ============================================================== -->
                        <!-- gross profit  -->
                        <!-- ============================================================== -->

                        <!-- ============================================================== -->
                        <!-- end gross profit  -->
                        <!-- ============================================================== -->
                        <!-- ============================================================== -->
                        <!-- profit margin  -->
                        <!-- ============================================================== -->
                    </div>
                </div>
                <!-- ============================================================== -->
                <!-- footer -->
                <!-- ============================================================== -->
                <div class="footer">
                    <?php include 'footer.php';?>
                </div>
                <!-- ============================================================== -->
                <!-- end footer -->
                <!-- ============================================================== -->
            </div>
            <!-- ============================================================== -->
            <!-- end wrapper  -->
            <!-- ============================================================== -->
        </div>
        <!-- ============================================================== -->
        <!-- end main wrapper  -->
        <!-- ============================================================== -->
        <!-- Optional JavaScript -->
        <!-- jquery 3.3.1 js-->
        <script src="assets/vendor/jquery/jquery-3.3.1.min.js"></script>
        <!-- bootstrap bundle js-->
        <script src="assets/vendor/bootstrap/js/bootstrap.bundle.js"></script>
        <!-- slimscroll js-->
        <script src="assets/vendor/slimscroll/jquery.slimscroll.js"></script>
        <!-- chartjs js-->
        <script src="assets/vendor/charts/charts-bundle/Chart.bundle.js"></script>
        <script src="assets/vendor/charts/charts-bundle/chartjs.js"></script>

        <!-- main js-->
        <script src="assets/libs/js/main-js.js"></script>
        <!-- jvactormap js-->
        <script src="assets/vendor/jvectormap/jquery-jvectormap-2.0.2.min.js"></script>
        <script src="assets/vendor/jvectormap/jquery-jvectormap-world-mill-en.js"></script>
        <!-- sparkline js-->
        <script src="assets/vendor/charts/sparkline/jquery.sparkline.js"></script>
        <script src="assets/vendor/charts/sparkline/spark-js.js"></script>
        <!-- dashboard sales js-->
        <script src="assets/libs/js/dashboard-sales.js"></script>
    </body>
</html>
