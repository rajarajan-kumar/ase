<!doctype html>
<html lang="en">

 
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="assets/vendor/bootstrap/css/bootstrap.min.css">
    <link href="assets/vendor/fonts/circular-std/style.css" rel="stylesheet">
    <link rel="stylesheet" href="assets/libs/css/style.css">
    <link rel="stylesheet" href="assets/vendor/fonts/fontawesome/css/fontawesome-all.css">
    <link rel="stylesheet" href="assets/vendor/vector-map/jqvmap.css">
    <link rel="stylesheet" href="assets/vendor/jvectormap/jquery-jvectormap-2.0.2.css">
    <link rel="stylesheet" href="assets/vendor/fonts/flag-icon-css/flag-icon.min.css">
    <title>ASE Admin</title>
</head>

<body>
    <!-- ============================================================== -->
    <!-- main wrapper -->
    <!-- ============================================================== -->
    <div class="dashboard-main-wrapper">
        <!-- ============================================================== -->
        <!-- navbar -->
        <!-- ============================================================== -->
        <div class="dashboard-header">
             <?php include 'nav.php'?>
        </div>
        <!-- ============================================================== -->
        <!-- end navbar -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <!-- left sidebar -->
        <!-- ============================================================== -->
        <div class="nav-left-sidebar sidebar-dark">
             <div class="menu-list">
                 <?php include 'menu.php'?>
                </div>
        </div>
        <!-- ============================================================== -->
        <!-- end left sidebar -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <!-- wrapper  -->
        <!-- ============================================================== -->
        <div class="dashboard-wrapper">
            <div class="container dashboard-content">
                <!-- ============================================================== -->
                <!-- pagehader  -->
                <!-- ============================================================== -->
                <div class="row">
                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                        <div class="page-header">
                            <h3 class="mb-2">New Registration</h3>
                           
                            <div class="page-breadcrumb">
                                <nav aria-label="breadcrumb">
                                    <ol class="breadcrumb">
                                        <li class="breadcrumb-item"><a href="#" class="breadcrumb-link">ASE Admin</a></li>
                                        <li class="breadcrumb-item active" aria-current="page">New Registration</li>
                                    </ol>
                                </nav>
                            </div>
                        </div>
                    </div>
                </div>

        <section id="about" class="about-mf sect-pt4 route card">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <div class="box-shadow-full">
                           
                            <div class="row">
                                <div class="col-md-12 align-items-center">
                                    <div class="align-middle">
                                    
                                        <form action="#" method="post">
                                          <div class="boxes-tpye">
                                            <div class="title-box text-center">
                                        <h3 class="title-a" style="font-size: 24px; text-transform: capitalize; color: #0078ff;">Personal Information</h3>
                                        
                                        <!-- <div class="line-mf"></div> -->
                                               </div>
                                            <div class="row">
                                                <div class="form-group col-md-4">
                                                    <input type="text" class="form-control" required="" placeholder="Name" name="name" />
                                                </div>
                                                <div class="form-group col-md-4">
                                                    <input type="text" class="form-control" required="" placeholder="Father Name" name="fname" />
                                                </div>
                                                <div class="form-group col-md-4">
                                                    <input type="text" class="form-control" required="" placeholder="Mother Name" name="mname" />
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="form-group col-md-4">
                                                   <select class="form-control" id="exampleFormControlSelect1">
                                                        <option>Gender</option>
                                                        <option>Male</option>
                                                        <option>Female</option>
                                                        <option>Other</option>
                                                    </select>
                                                </div>
                                                <div class="form-group col-md-4">
                                                    <input type="text" class="form-control" required="" placeholder="DD-MM-YYYY" name="dob" />
                                                </div>
                                                <div class="form-group col-md-4">
                                                    <input type="text" class="form-control" required="" placeholder="Mobile Number " name="mobile" />
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="form-group col-md-4">
                                                    <input type="text" class="form-control" required="" placeholder="Alternate Contact Number" name="amobile" />
                                                </div>
                                                <div class="form-group col-md-4">
                                                     <input type="mail" class="form-control" required="" placeholder="Email" name="email" />
                                                </div>
                                                <div class="form-group col-md-4">
                                                    <input type="text" class="form-control" required="" placeholder="Door No / Flat No / Name" name="pan" />
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="form-group col-md-4">
                                                    <input type="text" class="form-control" required="" placeholder="Street Name" name="Street Name" />
                                                </div>
                                                <div class="form-group col-md-4">
                                                    <input type="text" class="form-control" required="" placeholder="Locality" name="pan" />
                                                </div>
                                                <div class="form-group col-md-4">
                                                    <input type="text" class="form-control" required="" placeholder="District " name="district" />
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="form-group col-md-4">
                                                    <input type="text" class="form-control" required="" placeholder="State" name="state" />
                                                </div>
                                                 
                                                
                                                <div class="form-group col-md-4">
                                                    <input type="text" class="form-control" required="" placeholder="Country" name="country" />
                                                </div>
                                               
                                                
                                            </div>
                                            </div>
                                        </div>
                                              <div class="boxes-tpye">
                                              <div class="title-box text-center">
                                        <h3 class="title-a" style="font-size: 24px; text-transform: capitalize; color: #0078ff;">Occupation Details</h3>
                                        
                                        <!-- <div class="line-mf"></div> -->
                                               </div>
    <div class="row">
         <div class="form-group col-md-6">
                                                   <select class="form-control" id="exampleFormControlSelect1">
                                                        <option>Choose Occupation</option>
                                                        <option>Self Employed</option>
                                                        <option>Salaried</option>
                                                        
                                                    </select>
                                                </div>
                                                <div class="form-group col-md-6">
                                                    <input type="text" class="form-control" required="" placeholder="Business Type" name="pan" />
                                                </div>
       
        <div class="form-group col-md-6">
            <input type="text" class="form-control" required="" placeholder="Income" name="income" />
        </div>
         <div class="form-group col-md-6">
            <input type="text" class="form-control" required="" placeholder="Business Location" name="b-location" />
        </div>
    </div>


   
</div>
                                            <div class="boxes-tpye">
                                              <div class="title-box text-center">
                                        <h3 class="title-a" style="font-size: 24px; text-transform: capitalize; color: #0078ff;">Bank Details</h3>
                                        
                                        <!-- <div class="line-mf"></div> -->
                                               </div>
    <div class="row">
        <div class="form-group col-md-4">
            <input type="text" class="form-control" required="" placeholder="Pancard" name="name" />
        </div>
        <div class="form-group col-md-4">
            <input type="text" class="form-control" required="" placeholder="Aadhar card" name="fname" />
        </div>
        <div class="form-group col-md-4">
            <input type="text" class="form-control" required="" placeholder="Bank name" name="mname" />
        </div>
    </div>


    <div class="row">
        
        <div class="form-group col-md-4">
            <input type="text" class="form-control" required="" placeholder="Account number" name="acno" />
        </div>
        <div class="form-group col-md-4">
            <input type="text" class="form-control" required="" placeholder="IFSC Code" name="ifsc" />
        </div>
        <div class="form-group col-md-4">
            <input type="text" class="form-control" required="" placeholder="Branch" name="branch" />
        </div>
    </div>
</div>
                                           <div class="boxes-tpye">
                                            <div class="title-box text-center">
                                        <h3 class="title-a" style="font-size: 24px; text-transform: capitalize; color: #0078ff;">Invesment Details </h3>
                                        
                                        
                                               </div>
                                            <div class="row">
                                                <div class="form-group col-md-4">
                                                    <input type="text" class="form-control" required="" placeholder="Nominee" name="nominee" />
                                                </div>
                                                <div class="form-group col-md-4">
                                                    <input type="text" class="form-control" required="" placeholder="Relationship" name="relationship" />
                                                </div>
                                                <div class="form-group col-md-4">
                                                    <input type="text" class="form-control" required="" placeholder="Nominee Contact Number" name="nom-con-number" />
                                                </div>
                                            </div>
                                            
                                            <div class="row">
                                                <div class="form-group col-md-4">
                                                    <input type="text" class="form-control" required="" placeholder="Nominee Email id" name="nom-email" />
                                                </div>
                                                <div class="form-group col-md-4">
                                                     <input type="text" class="form-control" required="" placeholder="Refferal ID" name="refferalid" />
                                                </div>
                                               <!--  <div class="form-group col-md-4">
                                                    <input type="text" class="form-control" required="" placeholder="Amount Investing" name="amountinvesting" />
                                                </div> -->
                                            </div>
                                            <!-- <div class="row">
                                                <div class="form-group col-md-4">
                                                    <input type="text" class="form-control" required="" placeholder="Placement" name="placement" />
                                                </div>
                                               
                                            </div> -->
                                            </div>
                                               <div class="form-group col-md-12 reg-txt">
                                                <input type="submit" value="Submit" class="btn btn-primary btn-radius" />
                                            </div>


                                        </form>
                                    
                                   
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

            </div>
            <!-- ============================================================== -->
            <!-- footer -->
            <!-- ============================================================== -->
            <div class="footer">
               <?php include 'footer.php';?>
            </div>
            <!-- ============================================================== -->
            <!-- end footer -->
            <!-- ============================================================== -->
        </div>
        <!-- ============================================================== -->
        <!-- end wrapper  -->
        <!-- ============================================================== -->
    </div>
    <!-- ============================================================== -->
    <!-- end main wrapper  -->
    <!-- ============================================================== -->
    <!-- Optional JavaScript -->
    <!-- jquery 3.3.1 js-->
    <script src="assets/vendor/jquery/jquery-3.3.1.min.js"></script>
    <!-- bootstrap bundle js-->
    <script src="assets/vendor/bootstrap/js/bootstrap.bundle.js"></script>
    <!-- slimscroll js-->
    <script src="assets/vendor/slimscroll/jquery.slimscroll.js"></script>
    <!-- chartjs js-->
    <script src="assets/vendor/charts/charts-bundle/Chart.bundle.js"></script>
    <script src="assets/vendor/charts/charts-bundle/chartjs.js"></script>
   
    <!-- main js-->
    <script src="assets/libs/js/main-js.js"></script>
    <!-- jvactormap js-->
    <script src="assets/vendor/jvectormap/jquery-jvectormap-2.0.2.min.js"></script>
    <script src="assets/vendor/jvectormap/jquery-jvectormap-world-mill-en.js"></script>
    <!-- sparkline js-->
    <script src="assets/vendor/charts/sparkline/jquery.sparkline.js"></script>
    <script src="assets/vendor/charts/sparkline/spark-js.js"></script>
     <!-- dashboard sales js-->
    <script src="assets/libs/js/dashboard-sales.js"></script>
</body>
 
</html>