<!doctype html>
<html lang="en">

 
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="assets/vendor/bootstrap/css/bootstrap.min.css">
    <link href="assets/vendor/fonts/circular-std/style.css" rel="stylesheet">
    <link rel="stylesheet" href="assets/libs/css/style.css">
    <link rel="stylesheet" href="assets/vendor/fonts/fontawesome/css/fontawesome-all.css">
    <link rel="stylesheet" href="assets/vendor/vector-map/jqvmap.css">
    <link rel="stylesheet" href="assets/vendor/jvectormap/jquery-jvectormap-2.0.2.css">
    <link rel="stylesheet" href="assets/vendor/fonts/flag-icon-css/flag-icon.min.css">
    <title>ASE Admin</title>
</head>

<body>
    <!-- ============================================================== -->
    <!-- main wrapper -->
    <!-- ============================================================== -->
    <div class="dashboard-main-wrapper">
        <!-- ============================================================== -->
        <!-- navbar -->
        <!-- ============================================================== -->
        <div class="dashboard-header">
             <?php include 'nav.php'?>
        </div>
        <!-- ============================================================== -->
        <!-- end navbar -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <!-- left sidebar -->
        <!-- ============================================================== -->
        <div class="nav-left-sidebar sidebar-dark">
             <div class="menu-list">
                 <?php include 'menu.php'?>
                </div>
        </div>
        <!-- ============================================================== -->
        <!-- end left sidebar -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <!-- wrapper  -->
        <!-- ============================================================== -->
        <div class="dashboard-wrapper">
            <div class="container dashboard-content">
                <!-- ============================================================== -->
                <!-- pagehader  -->
                <!-- ============================================================== -->
                <div class="row">
                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                        <div class="page-header">
                            <h3 class="mb-2">New Registration</h3>
                           
                            <div class="page-breadcrumb">
                                <nav aria-label="breadcrumb">
                                    <ol class="breadcrumb">
                                        <li class="breadcrumb-item"><a href="#" class="breadcrumb-link">ASE Admin</a></li>
                                        <li class="breadcrumb-item active" aria-current="page">New Registration</li>
                                    </ol>
                                </nav>
                            </div>
                        </div>
                    </div>
                </div>

        <section id="about" class="about-mf sect-pt4 route card">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <div class="box-shadow-full">
                           
                            <div class="row">
                                <div class="col-md-12 align-items-center">
                                    <div class="align-middle">
                                    
                                        <form action="#" method="post">
                                          <div class="boxes-tpye">
                                            <div class="title-box text-center">
                                        <h3 class="title-a" style="font-size: 24px; text-transform: capitalize; color: #0078ff;">Personal Information</h3>
                                        
                                        <!-- <div class="line-mf"></div> -->
                                               </div>
                                            <div class="row">
                                                <div class="form-group col-md-4">
                                                    <input type="text" class="form-control" required="" value="Name" name="name" />
                                                </div>
                                                <div class="form-group col-md-4">
                                                    <input type="text" class="form-control" required="" value="Father Name" name="fname" />
                                                </div>
                                                <div class="form-group col-md-4">
                                                    <input type="text" class="form-control" required="" value="Mother Name" name="mname" />
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="form-group col-md-4">
                                                   <select class="form-control" id="exampleFormControlSelect1">
                                                        <option>Gender</option>
                                                        <option>Male</option>
                                                        <option>Female</option>
                                                        <option>Other</option>
                                                    </select>
                                                </div>
                                                <div class="form-group col-md-4">
                                                    <input type="text" class="form-control" required="" value="DD-MM-YYYY" name="dob" />
                                                </div>
                                                <div class="form-group col-md-4">
                                                    <input type="text" class="form-control" required="" value="Mobile Number " name="mobile" />
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="form-group col-md-4">
                                                    <input type="text" class="form-control" required="" value="Alternate Contact Number" name="amobile" />
                                                </div>
                                                <div class="form-group col-md-4">
                                                     <input type="mail" class="form-control" required="" value="Email" name="email" />
                                                </div>
                                                <div class="form-group col-md-4">
                                                    <input type="text" class="form-control" required="" value="Door No / Flat No / Name" name="pan" />
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="form-group col-md-4">
                                                    <input type="text" class="form-control" required="" value="Street Name" name="Street Name" />
                                                </div>
                                                <div class="form-group col-md-4">
                                                    <input type="text" class="form-control" required="" value="Locality" name="pan" />
                                                </div>
                                                <div class="form-group col-md-4">
                                                    <input type="text" class="form-control" required="" value="District " name="district" />
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="form-group col-md-4">
                                                    <input type="text" class="form-control" required="" value="State" name="state" />
                                                </div>
                                                 
                                                
                                                <div class="form-group col-md-4">
                                                    <input type="text" class="form-control" required="" value="Country" name="country" />
                                                </div>
                                               
                                                
                                            </div>
                                            </div>
                                        </div>
                                              <div class="boxes-tpye">
                                              <div class="title-box text-center">
                                        <h3 class="title-a" style="font-size: 24px; text-transform: capitalize; color: #0078ff;">Occupation Details</h3>
                                        
                                        <!-- <div class="line-mf"></div> -->
                                               </div>
    <div class="row">
         <div class="form-group col-md-6">
                                                   <select class="form-control" id="exampleFormControlSelect1">
                                                        <option>Choose Occupation</option>
                                                        <option>Self Employed</option>
                                                        <option>Salaried</option>
                                                        
                                                    </select>
                                                </div>
                                                <div class="form-group col-md-6">
                                                    <input type="text" class="form-control" required="" value="Business Type" name="pan" />
                                                </div>
       
        <div class="form-group col-md-6">
            <input type="text" class="form-control" required="" value="Income" name="income" />
        </div>
         <div class="form-group col-md-6">
            <input type="text" class="form-control" required="" value="Business Location" name="b-location" />
        </div>
    </div>


   
</div>
                                            <div class="boxes-tpye">
                                              <div class="title-box text-center">
                                        <h3 class="title-a" style="font-size: 24px; text-transform: capitalize; color: #0078ff;">Bank Details</h3>
                                        
                                        <!-- <div class="line-mf"></div> -->
                                               </div>
    <div class="row">
        <div class="form-group col-md-4">
            <input type="text" class="form-control" required="" value="Pancard" name="name" />
        </div>
        <div class="form-group col-md-4">
            <input type="text" class="form-control" required="" value="Aadhar card" name="fname" />
        </div>
        <div class="form-group col-md-4">
            <input type="text" class="form-control" required="" value="Bank name" name="mname" />
        </div>
    </div>


    <div class="row">
        
        <div class="form-group col-md-4">
            <input type="text" class="form-control" required="" value="Account number" name="acno" />
        </div>
        <div class="form-group col-md-4">
            <input type="text" class="form-control" required="" value="IFSC Code" name="ifsc" />
        </div>
        <div class="form-group col-md-4">
            <input type="text" class="form-control" required="" value="Branch" name="branch" />
        </div>
    </div>
</div>
                                           <div class="boxes-tpye">
                                            <div class="title-box text-center">
                                        <h3 class="title-a" style="font-size: 24px; text-transform: capitalize; color: #0078ff;">Invesment Details </h3>
                                        
                                        
                                               </div>
                                            <div class="row">
                                                <div class="form-group col-md-4">
                                                    <input type="text" class="form-control" required="" value="Nominee" name="nominee" />
                                                </div>
                                                <div class="form-group col-md-4">
                                                    <input type="text" class="form-control" required="" value="Relationship" name="relationship" />
                                                </div>
                                                <div class="form-group col-md-4">
                                                    <input type="text" class="form-control" required="" value="Nominee Contact Number" name="nom-con-number" />
                                                </div>
                                            </div>
                                            
                                            <div class="row">
                                                <div class="form-group col-md-4">
                                                    <input type="text" class="form-control" required="" value="Nominee Email id" name="nom-email" />
                                                </div>
                                                <div class="form-group col-md-4">
                                                     <input type="text" class="form-control" required="" value="Refferal ID" name="refferalid" />
                                                </div>
                                                
                                            </div>
                                            <!-- <div class="row">
                                                <div class="form-group col-md-4">
                                                    <input type="text" class="form-control" required="" value="Placement" name="placement" />
                                                </div>
                                               
                                            </div> -->
                                            </div>
                                               <div class="form-group col-md-12 reg-txt">
                                                <input type="submit" value="Submit" class="btn btn-primary btn-radius" />
                                            </div>


                                        </form>
                                    
                                   
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

            </div>
            <!-- ============================================================== -->
            <!-- footer -->
            <!-- ============================================================== -->
            <div class="footer">
               <?php include 'footer.php';?>
            </div>
            <!-- ============================================================== -->
            <!-- end footer -->
            <!-- ============================================================== -->
        </div>
        <!-- ============================================================== -->
        <!-- end wrapper  -->
        <!-- ============================================================== -->
    </div>
    <!-- ============================================================== -->
    <!-- end main wrapper  -->
    <!-- ============================================================== -->
    <!-- Optional JavaScript -->
    <!-- jquery 3.3.1 js-->
    <script src="assets/vendor/jquery/jquery-3.3.1.min.js"></script>
    <!-- bootstrap bundle js-->
    <script src="assets/vendor/bootstrap/js/bootstrap.bundle.js"></script>
    <!-- slimscroll js-->
    <script src="assets/vendor/slimscroll/jquery.slimscroll.js"></script>
    <!-- chartjs js-->
    <script src="assets/vendor/charts/charts-bundle/Chart.bundle.js"></script>
    <script src="assets/vendor/charts/charts-bundle/chartjs.js"></script>
   
    <!-- main js-->
    <script src="assets/libs/js/main-js.js"></script>
    <!-- jvactormap js-->
    <script src="assets/vendor/jvectormap/jquery-jvectormap-2.0.2.min.js"></script>
    <script src="assets/vendor/jvectormap/jquery-jvectormap-world-mill-en.js"></script>
    <!-- sparkline js-->
    <script src="assets/vendor/charts/sparkline/jquery.sparkline.js"></script>
    <script src="assets/vendor/charts/sparkline/spark-js.js"></script>
     <!-- dashboard sales js-->
    <script src="assets/libs/js/dashboard-sales.js"></script>
</body>
 
</html>