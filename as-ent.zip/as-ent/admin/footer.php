<div class="container-fluid">
                        <div class="row">
                            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                                Copyright © 2021 AS Enterprises. All rights reserved. Designed by Sadetechno Solutions.
                            </div>
                        </div>
                    </div>