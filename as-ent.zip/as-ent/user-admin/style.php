 <!-- Required meta tags -->
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <!-- Bootstrap CSS -->
        <link rel="stylesheet" href="assets/vendor/bootstrap/css/bootstrap.min.css" />
        <link href="assets/vendor/fonts/circular-std/style.css" rel="stylesheet" />
        <link rel="stylesheet" href="assets/libs/css/style.css" />
        <link rel="stylesheet" href="assets/vendor/fonts/fontawesome/css/fontawesome-all.css" />
        <link rel="stylesheet" href="assets/vendor/vector-map/jqvmap.css" />
        <link rel="stylesheet" href="assets/vendor/jvectormap/jquery-jvectormap-2.0.2.css" />
        <link rel="stylesheet" href="assets/vendor/fonts/flag-icon-css/flag-icon.min.css" />
        <title>ASE User Admin</title>